💼 Project Title: Video Game Sales Analysis (Kaggle Dataset)

📌 Objective:
Analyze video game sales to identify top-selling games, popular genres, and yearly sales trends.

📊 Key Insights:
1. Top 5 best-selling games globally
2. Most profitable genre
3. Sales trend by year

🛠 Tools Used:
SQL, Tableau

📈 Outcome:
Provided actionable insights on game sales trends that could help in future game marketing strategies.